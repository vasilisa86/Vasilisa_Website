//Function to add new Brands in the Brands List
function addItem() { //create function to onclick
  value = document.querySelector('[brand-item]').value; //get value from [brand-item] 
  ul = document.querySelector('[brand-list]');  // assign value to ul 
  li = document.createElement('li'); //assign value to li 
  li.innerHTML = value; //add value to li  
  ul.appendChild(li); //attach li to ul HTML page
  document.querySelector('[brand-item]').value = ''; //clear to null input field after submit
}